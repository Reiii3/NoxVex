$AXFUN

check=$(settings list system | grep -qE "high_performance_mode_on|high_performance_mode_on_when_shutdown" && echo true || echo false)

ai_op() {
    cmd settings put system high_performance_mode_on 1
    cmd settings put system high_performance_mode_on_when_shutdown 1
}

ai_op_r() {
    cmd settings put system high_performance_mode_on 0
    cmd settings put system high_performance_mode_on_when_shutdown 0
}

if [[ "$1" = true ]]; then
  cmd package compile -m everything-profile -f "$MODULE_PKG" >/dev/null 2>&1
  cmd package compile -m quicken -f "$MODULE_PKG" >/dev/null 2>&1
  cmd package compile -m speed --secondary-dex -f "$MODULE_PKG" >/dev/null 2>&1
  cmd package reconcile-secondary-dex-files "$MODULE_PKG" >/dev/null 2>&1
  cmd package compile --compile-layouts --secondary-dex -f "$MODULE_PKG" >/dev/null 2>&1
  simpleperf --log fatal --log-to-android-buffer 0 >/dev/null 2>&1
  cmd power set-adaptive-power-saver-enabled false >/dev/null 2>&1
  cmd power set-fixed-performance-mode-enabled true >/dev/null 2>&1
  cmd power set-mode 0 >/dev/null 2>&1
  cmd thermalservice override-status 0 >/dev/null 2>&1
  cmd power set-adaptive-power-saver-enabled false >/dev/null 2>&1
  cmd power set-fixed-performance-mode-enabled true >/dev/null 2>&1
  if [[ $check ]]; then
    ai_op
  fi
  echo "NoVex System Active in : $(pkglist -L $MODULE_PKG)"
else
  cmd package compile -m verify -f "$MODULE_PKG" >/dev/null 2>&1
  cmd thermalservice reset >/dev/null 2>&1
  cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1
  cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1
  cmd power set-mode 1 >/dev/null 2>&1
  cmd power set-adaptive-power-saver-enabled true >/dev/null 2>&1
  cmd power set-fixed-performance-mode-enabled false >/dev/null 2>&1
  if [[ $check ]]; then
    ai_op_r
  fi
  echo "NoVex System Deactive in : $(pkglist -L $MODULE_PKG)"
fi