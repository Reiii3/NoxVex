$AXFUN

if [[ "$1" = "true" ]]; then
  am force-stop com.google.android.gms >/dev/null 2>&1
  cmd activity force-stop com.xiaomi.joyose >/dev/null 2>&1
  dumpsys deviceidle whitelist -com.google.android.gms >/dev/null 2>&1
  dumpsys deviceidle force-idle >/dev/null 2>&1
  dumpsys deviceidle step deep >/dev/null 2>&1
  echo "Disable GMS succesfuly"
else
  dumpsys deviceidle whitelist +com.google.android.gms >/dev/null 2>&1
  dumpsys deviceidle unforce >/dev/null 2>&1
  dumpsys deviceidle step active >/dev/null 2>&1
  echo "Enable GMS succesfuly"
fi