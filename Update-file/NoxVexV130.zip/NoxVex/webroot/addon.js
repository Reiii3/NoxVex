import Axeron from "/axeron.js";
import AxConstant from "/axConstant.js";
import Dialog from 'https://fahrez.one/dialog.js';

class Main {
  thisDataPath = `/sdcard/Android/data/${AxConstant.MODULE_PKG}`;
  shellPath = `${AxConstant.MODULE_PATH}/shell/addon`;
  setDriverDelete = "settings delete global driver_package";
  setDynSfDelete = "settings delete global dyn_sf_game"
  setAddon3Delete = "settings delete global addon_3_ex"
  setAddon4Delete = "settings delete global addon_4_ex"
  setScaleDelete = "settings delete global scale_opt_mod"
  setFreshDelete = "settings delete global fresh_opt_mod"
  setDriverGet = "settings get global driver_package";
  setDriverPut = "settings put global driver_package $MODULE_PKG";
  setDynSfGet = "settings get global dyn_sf_game"
  setDynSfPut = "settings put global dyn_sf_game true"
  setAddon3Get = "settings get global addon_3_ex"
  setAddon3Put = "settings put global addon_3_ex true"
  setAddon4Get = "settings get global addon_4_ex"
  setAddon4Put = "settings put global addon_4_ex true"
  setScalePut = "settings put global scale_opt_mod"
  setScaleGet = "settings get global scale_opt_mod"
  setFreshGet = "settings get global fresh_opt_mod"
  switchAddon1;
  switchAddon2;
  switchAddon3;
  switchAddon4;
  linkTele = `am start -a android.intent.action.VIEW -d "https://t.me/JaaGabu"`;
  linkFitur = "./index.html";
  linkMenu = "./addon.html";
  textId;
  textAppImpacted;
  stringImpactedIs;
  btnOptimize;
  btnTeleCH;
  btnMenu;
  btnFitur;
  btnScale;
  currentDriverSetting = "";
  currentDynSetting = "";
  currentAddon3Setting = "";
  currentAddon4Setting = "";
  appName = "";

  constructor() {
    console.log("from constructor");
    this.initComponent();
    this.fetchSettings();
    const dialog = new Dialog();
    dialog.setTitle('Can\'t use this V-Mods');
    dialog.setSubtitle('You need to update Vortex Core');
    dialog.setCancelable(false);
    if (AxConstant.AX_VCODE < 241201900) {
      dialog.show();
    }
  }

  async fetchSettings() {
    try {
      const { stdout: getDriverSettings } = await Axeron.exec(
          this.setDriverGet
        );
      this.currentDriverSetting = getDriverSettings;
      console.log(`Nilai DRIVER : ${this.currentDriverSetting}`);
      
      const { stdout: getDynSfSettings } = await Axeron.exec(
        this.setDynSfGet
      );
      this.currentDynSetting = getDynSfSettings;
      console.log(`Nilai DYN : ${this.currentDynSetting}`);
      
      const { stdout: getAddon3Settings } = await Axeron.exec(
        this.setAddon3Get
      );
      this.currentAddon3Setting = getAddon3Settings;
      console.log(`Nilai ADDON3 ${this.currentAddon3Setting}`);
      
      const { stdout: getAddon4Settings } = await Axeron.exec(
        this.setAddon4Get
      );
      this.currentAddon4Setting = getAddon4Settings;
      console.log(`Nilai ADDON4 ${this.currentAddon4Setting}`);
      
      const { stdout: getScaleSettings } = await Axeron.exec(
        this.setScaleGet
      );
      this.currentScaleSetting = getScaleSettings;
      
      const { stdout: getFreshSettings } = await Axeron.exec(
        this.setFreshGet
      );
      this.currentFreshSetting = getFreshSettings;
      
      if (this.currentFreshSetting == "null" || this.currentFreshSetting == "freshDef") {
        this.btnDefaultFresh = document.getElementById("freshDef");
        this.btnDefaultFresh.style.background = "#4F6BD8";
        this.btnDefaultFresh.style.transition = "background 0.3s"
      } else {
        this.btnDefaultFresh = document.getElementById(this.currentFreshSetting);
        this.btnDefaultFresh.style.background = "#4F6BD8";
        this.btnDefaultFresh.style.transition = "background 0.3s"
      }// fungsi ini di gunakan untuk mengupdate warna button saat habis relog dari module
      
      const { stdout: nameAppImpacted } = await Axeron.exec(
          "pkglist -L " + getDriverSettings
      );
      this.putColorScale(this.currentScaleSetting);
      
      this.textAddDriver.innerHTML = `${this.stringDriverLs} <span style="color: #ff5503">${nameAppImpacted}</span>`;
      if (this.currentDriverSetting == "null") {
        this.textDelDriver.innerHTML = `${this.stringDriverDl} <span style="color: #ff5503">Deleted</span>`;
      }
      const { stdout: nameApp } = await Axeron.exec(
        "pkglist -L " + AxConstant.MODULE_PKG
      );
      
      this.appName = nameApp;
      this.updateSwitchState();
    } catch (error) {
      Axeron.toast("Error", error.toString());
    }
  }

  updateSwitchState() {
     if (this.currentDriverSetting == AxConstant.MODULE_PKG) {
      if (this.switchAddon1) {
        this.switchAddon1.checked = true;
      }
     }
     
     if (this.currentDynSetting == "true") {
      if (this.switchAddon2) {
        this.switchAddon2.checked = true;
      }
     }
     if (this.currentAddon3Setting == "true") {
      if (this.switchAddon3) {
        this.switchAddon3.checked = true;
      }
     }
     if (this.currentAddon4Setting == "true") {
      if (this.switchAddon4) {
        this.switchAddon4.checked = true;
      }
     }
  }

  initComponent() {
    this.switchAddon1 = document.getElementById("toggle_addon1");
    this.switchAddon2 = document.getElementById("toggle_addon2");
    this.switchAddon3 = document.getElementById("toggle_addon3");
    this.switchAddon4 = document.getElementById("toggle_addon4");
    this.textId = document.getElementById("id");
    this.textAddDriver = document.getElementById('app_drivered');
    this.textDelDriver = document.getElementById('app_drivered');
    this.btnTeleCH = document.getElementById("telegram_link");
    this.btnFitur = document.getElementById("fitur_link");
    this.btnMenu = document.getElementById("menu_link");
    this.idScale1 = document.getElementById("scale1");
    this.idScale2 = document.getElementById("scale2");
    this.idScale3 = document.getElementById("scale3");
    this.idScale4 = document.getElementById("scale4");
    this.idScale5 = document.getElementById("scale5");
    this.idScaleDef = document.getElementById("scaleDef");
    this.btnScale = document.querySelectorAll("button[name]");
    this.btnFresh = document.querySelectorAll("button[nameF]");
    this.textId.textContent = AxConstant.AX_ID;
    this.stringDriverLs = this.textAddDriver.textContent;
    this.stringDriverDl = this.textDelDriver.textContent;
    
    const textAppName = document.getElementById('app_name');
    textAppName.textContent = AxConstant.MODULE_PKG_NAME;
    
    const textAppPkg = document.getElementById('app_pkg');
    textAppPkg.textContent = AxConstant.MODULE_PKG;
    
    const textAppVName = document.getElementById('app_vname');
    textAppVName.textContent = 'V ' + AxConstant.MODULE_PKG_VNAME;
    
    const textAppVCode = document.getElementById('app_vcode');
    textAppVCode.textContent = AxConstant.MODULE_PKG_VCODE;
    
    const appIcon = document.getElementById('app_icon');
    
    const img = document.createElement('img');
    img.src = AxConstant.getPackageIcon(AxConstant.MODULE_PKG);
    img.alt = 'Gambar yang dimuat';
    
    appIcon.appendChild(img);
    this.initListeners();
  }
  
  async putScale() {
    const { stdout: getDriveSettings } = await Axeron.exec(
      this.setDriverPut + " && " + this.setDriverGet
    );
  }
  
  async checkFr(isColor) {
    const {stdout: getFreshCheck } = await Axeron.exec(
      this.setFreshGet
    );
    this.currentFreshSetting = getFreshCheck;
    if (getFreshCheck == "freshDef") {
      document.getElementById(getFreshCheck).style.background = "#505050";
      document.getElementById(isColor).style.background = "#4F6BD8";
      document.getElementById(isColor).style.transition = "background 0.4s";
    } else {
      document.getElementById(getFreshCheck).style.background = "transparent";
      document.getElementById(isColor).style.background = "#4F6BD8";
      document.getElementById(isColor).style.transition = "background 0.4s";
    }
  } // fungsi ini di gunakan untuk mengubah warna button sebelum nya
  
  async execFreshBypash(isVelueButton) {
    Axeron.exec(`velue="${isVelueButton}"; BBK_BRANDS="oppo vivo oneplus realme iqoo"; BRAND=$(getprop ro.product.brand | tr '[:upper:]' '[:lower:]'); FPS=$(dumpsys display | grep -oE 'fps=[0-9]+' | awk -F '=' '{print $2}' | head -n 1);if [ "$velue" != "deffault" ]; then if echo "$BBK_BRANDS" | grep -wq "$BRAND"; then [ "$FPS" -le 1 ] && FPS=1 || [ "$FPS" -le 2 ] && FPS=2 || [ "$FPS" -le 3 ] && FPS=3 || FPS=4; fi; settings put system peak_refresh_rate "$FPS"; settings put system user_refresh_rate "$FPS"; settings put system max_refresh_rate "$FPS"; settings put system min_refresh_rate "$FPS";cmd display set-match-content-frame-rate-pref 2; else settings delete system peak_refresh_rate;settings delete system user_refresh_rate;settings delete system max_refresh_rate;settings delete system min_refresh_rate;cmd display set-match-content-frame-rate-pref 1; fi`)
  }
  async putColorScale(isVelue) {
    if (isVelue == "null") {
      this.idScaleDef.style.background = "#4F6BD8";
      this.idScaleDef.style.transition = "background 0.4s";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "transparent";
    } else if (isVelue == "0.5") {
      this.idScaleDef.style.background = "#505050";
      this.idScale1.style.background = "#4F6BD8";
      this.idScale1.style.transition = "background 0.4s";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "transparent";
    } else if (isVelue == "0.8") {
      this.idScaleDef.style.background = "#505050";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "#4F6BD8";
      this.idScale2.style.transition = "background 0.4s";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "transparent";
    } else if (isVelue == "1.0") {
      this.idScaleDef.style.background = "#505050";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "#4F6BD8";
      this.idScale3.style.transition = "background 0.4s";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "transparent";
    } else if (isVelue == "1.5") {
      this.idScaleDef.style.background = "#505050";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "#4F6BD8";
      this.idScale4.style.transition = "background 0.4s";
      this.idScale5.style.background = "transparent";
    } else if (isVelue == "2.0") {
      this.idScaleDef.style.background = "#505050";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "#4F6BD8";
      this.idScale5.style.transition = "background 0.4s";
    } else if (isVelue == "deffault") {
      this.idScaleDef.style.background = "#4F6BD8";
      this.idScaleDef.style.transition = "background 0.4s";
      this.idScale1.style.background = "transparent";
      this.idScale2.style.background = "transparent";
      this.idScale3.style.background = "transparent";
      this.idScale4.style.background = "transparent";
      this.idScale5.style.background = "transparent";
    } else {
      console.log('terjadi kesalahan')
    }
  }
  
  async execDriver(isDisable) {
    const execDriver = `sh ${this.shellPath}/driver_game.sh ${isDisable} ${AxConstant.MODULE_PKG}`;
    const { stdout: getDriverSettings } = await Axeron.exec(
          execDriver
    );
    if (isDisable) {
      Axeron.toast("Activated", getDriverSettings, 2200);
      const { stdout: getDriveSettings } = await Axeron.exec(
          this.setDriverPut + " && " + this.setDriverGet
      );
      this.textAddDriver.innerHTML = `${this.stringDriverLs} <span style="color: #ff5503">${this.appName}</span>`;
    } else {
      Axeron.toast("Disabled", getDriverSettings, 2200);
      Axeron.exec(this.setDriverDelete);
      console.log(`NILAI Removed Driver ${this.currentDriverSetting}`);
      this.textDelDriver.innerHTML = `${this.stringDriverDl} <span style="color: #ff5503">Deleted</span>`;
    }
  }
  
  async execDyn(isDisable) {
    const execDynSf = `sh ${this.shellPath}/dyn_sf.sh ${isDisable}`;
    const { stdout: getDynSfSettings } = await Axeron.exec(
      execDynSf
    );
    if (isDisable) {
      Axeron.toast("Activated", getDynSfSettings, 2200);
      const { stdout: getDynSettings } = await Axeron.exec(
       this.setDynSfPut + " && " + this.setDynSfGet
      );
    } else {
      Axeron.toast("Disabled", getDynSfSettings, 2200);
      Axeron.exec(this.setDynSfDelete);
      console.log(`NILAI Remove Dyn ${this.currentDynSetting}`);
    }
  }
  
  async execAddon3(isDisable) {
    const execAddon3 = `sh ${this.shellPath}/addon3.sh ${isDisable}`;
    const { stdout: getAddon3Setting } = await Axeron.exec(
      execAddon3
    );
    if (isDisable) {
      Axeron.toast("Activated", getAddon3Setting , 2200);
      const { stdout: getAdd3Setting } = await Axeron.exec(
        this.setAddon3Put + " && " + this.setAddon3Get
      );
    } else {
      Axeron.toast("Disabled", getAddon3Setting, 2200);
      Axeron.exec(this.setAddon3Delete);
      console.log(`NILAI Addon 3 Removed ${this.currentAddon3Setting}`);
    }
  }
  
  async execAddon4(isDisable) {
    const execAddon4 = `sh ${this.shellPath}/addon4.sh ${isDisable}`;
    const { stdout: getAdd4Settings } = await Axeron.exec(
          execAddon4
    );
    if (isDisable) {
      Axeron.toast("Activated", getAdd4Settings, 2200);
      const { stdout: getAdd4Setting } = await Axeron.exec(
        this.setAddon4Put + " && " + this.setAddon4Get
      );
    } else {
      Axeron.toast("Disabled", getAdd4Settings, 2200);
      Axeron.exec(this.setAddon4Delete);
    }
  }
  
  initListeners() {
    this.switchAddon1.addEventListener("change", () => {
      if (this.switchAddon1.checked) {
        console.log("Active");
        this.execDriver(true);
      } else {
        console.log("Non-Active");
        this.execDriver(false);
      }
    });
    
    this.switchAddon2.addEventListener("change", () => {
      if (this.switchAddon2.checked) {
        console.log("Active");
        this.execDyn(true);
      } else {
        console.log("Non-Active");
        this.execDyn(false);
      }
    });
    
    this.switchAddon3.addEventListener("change", () => {
      if (this.switchAddon3.checked) {
        console.log("Active");
        this.execAddon3(true);
      } else {
        console.log("Non-Active");
        this.execAddon3(false);
      }
    });
    
    this.switchAddon4.addEventListener("change", () => {
      if (this.switchAddon4.checked) {
        console.log("Active");
        this.execAddon4(true);
      } else {
        console.log("Non-Active");
        this.execAddon4(false);
      }
    });
    this.btnTeleCH.addEventListener("click", () => {
      console.log(`Masuk ke dalam ${this.linkTele}`);
      Axeron.exec(this.linkTele);
    });
    this.btnMenu.addEventListener("click", () => {
      console.log(`masuk ke dalam ${this.linkMenu}`);
      window.open(this.linkMenu, "_blank");
    });
    this.btnFitur.addEventListener("click", () => {
      console.log(`masuk ke dalam ${this.linkFitur}`);
      window.open(this.linkFitur, "_blank");
    });
    // Axeron.exec(`settings put global window_animation_scale ${velue};settings put global transition_animation_scale ${velue};settings put global animator_duration_scale ${velue}`);
    this.btnScale.forEach(velueBtn => {
      velueBtn.addEventListener("click", () => {
        this.velueExec = velueBtn.getAttribute('name');
        this.setScalePut = `settings put global scale_opt_mod ${this.velueExec}`;
        if (this.velueExec !== "deffault") {
          Axeron.exec(this.setScalePut + "&&" + this.setScaleGet);
          Axeron.exec(`settings put global window_animation_scale ${this.velueExec};settings put global transition_animation_scale ${this.velueExec};settings put global animator_duration_scale ${this.velueExec}`);
          console.log(`Custom Velue ${this.velueExec}`)
          Axeron.toast(`Animation Scale`, `Animation Set To ${this.velueExec}`, 1500);
          this.putColorScale(this.velueExec);
        } else {
          Axeron.exec(this.setScaleDelete);
          Axeron.exec(`settings put global window_animation_scale 1.0;settings put global transition_animation_scale 1.0;settings put global animator_duration_scale 1.0`);
          console.log(`Deffault Velue ${this.velueExec}`)
          Axeron.toast(`Animation Scale`, `Animation Set To Deffault`, 1500);
          this.putColorScale(this.velueExec)
        }
      })
    });
    this.btnFresh.forEach(velueBtnF => {
      velueBtnF.addEventListener("click", () => {
        this.idButton = velueBtnF.id;
        this.velueExecF = velueBtnF.getAttribute('nameF');
        this.exec = `settings put global fresh_opt_mod ${this.idButton}`;
        if (this.velueExecF !== "default") {
          this.checkFr(this.idButton);
          Axeron.exec(this.exec + "&&" + this.setFreshGet);
          Axeron.toast('Refresh Rate', `Selection Refresh Rate ${this.velueExecF}Hz`, 1500);
          this.execFreshBypash(this.velueExecF);
        } else {
          this.checkFr(this.idButton);
          Axeron.exec(this.setFreshDelete);
          Axeron.toast('Refresh Rate', `Set Refresh Rate To Deffault`, 1500);
          this.execFreshBypash(this.velueExecF);
        }
      });
    });
  }
}

export default new Main();
