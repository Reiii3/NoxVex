$AXFUN

if [[ "$1" = "true" ]]; then
  echo "Render Set To SkiaVK & Other" 
  setprop debug.hwui.renderer skiavk
  setprop debug.renderengine.backend skiavkthreaded
  setprop debug.hwui.shadow.renderer skiaglthreaded
  setprop debug.renderengine.vulkan true
  setprop debug.vulkan.enable_callback false
  setprop debug.vulkan.layers ""
  setprop debug.hwui.render_dirty_regions false
  setprop debug.hwui.skia_atrace_enabled false
  setprop debug.qsg_renderer 0
else
  setprop debug.hwui.renderer opengl
  setprop debug.renderengine.backend opengl
  setprop debug.hwui.shadow.renderer opengl
  setprop debug.renderengine.vulkan false
  setprop debug.vulkan.enable_callback true
  setprop debug.vulkan.layers ""
  setprop debug.hwui.render_dirty_regions true
  setprop debug.hwui.skia_atrace_enabled true
  setprop debug.qsg_renderer 1
  echo "Render Set To Deffault"
fi