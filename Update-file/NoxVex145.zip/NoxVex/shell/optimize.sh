$AXFUN

impactPkg=$(settings get global gimpact_package);
main() {
  cmd stats clear-puller-cache
  cmd activity clear-debug-app
  cmd activity clear-watch-heap -a
}

main "$@"